// phoenixMC_demo.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "phoenixMC_lib.h"
#pragma comment(lib,"phoenixMC.lib")
#include"getopt.h"
#pragma comment(lib,"getopt.lib")

#define FLASH_OP_NULL	0
#define FLASH_OP_READ	1
#define FLASH_OP_WRITE	2
#define FLASH_OP_ERASE	3

#define FW_OP_NULL		0
#define FW_OP_PARSE		1
#define FW_OP_UPDATE	2

#define FLASH_READ_SIZE		1024
#define FW_UPDATE_SIZE		(64*1024)

#define ERASE_TABLE_MAX		3
char* EraseSizeTableStr[ERASE_TABLE_MAX] = 
{
	"",
	"64kb",
	"4kb"
};
DWORD EraseSizeTable[ERASE_TABLE_MAX] = 
{
	0,
	(64*1024),
	(4*1024)
};

const CString BinFileName[] = {
	_T("boot"),
	_T("app"),
	_T("app_xip"),
	_T("net"),
	_T("net_ap"),
	_T("wlan_bl"),
	_T("wlan_fw"),
	_T("wlan_sdd"),
	_T("app_ext"),
};

void buf_dump(BYTE *buf, int len)
{
	for (int i=1;i<len+1;i++)
	{
		printf("%02X ", buf[i-1]);
		if (i%16 == 0)
			printf("\n");
	}
	printf("\n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	char ch;
	int flash_op = FLASH_OP_NULL;
	int fw_op = FW_OP_NULL;
	DWORD flash_address = -1, length = 0;
	int erase_size_index = 0;
	BYTE* pBuf;
	DWORD com, baud, i;
	CString key;
	CString strLeft, strRight, strRes, strTemp;
	CString file_path, image_path;

	if (argc < 2)
	{
		return 0;
	}
	while ((ch = getopt(argc, argv, _T("a:b:c:e:f:i:l:pruw:h?"))) != EOF) {
		switch(ch) {
			case 'a':
				flash_address = strtol(optarg, NULL, 0);
				break;
			case 'b':
				baud = atoi(optarg);
				break;
			case 'c':
				com = atoi(optarg);
				break;
			case 'e':
				flash_op = FLASH_OP_ERASE;
				for (i = 0;i < ERASE_TABLE_MAX;i++)
				{
					if (!strcmp(optarg, EraseSizeTableStr[i]))
					{
						erase_size_index = i;
						break;
					}
				}
				if (i == ERASE_TABLE_MAX)
				{
					printf("Invalid erase size: %s Should be:\n", optarg);
					for (i = 1;i < ERASE_TABLE_MAX;i++)
					{
						printf("%s ", EraseSizeTableStr[i]);
					}
					printf("\n");
					return -1;
				}
				break;
			case 'f':
				file_path = optarg;
				break;
			case 'i':
				image_path = optarg;
				break;
			case 'l':
				length = strtol(optarg, NULL, 0);
				break;
			case 'p':
				fw_op = FW_OP_PARSE;
				break;
			case 'r':
				flash_op = FLASH_OP_READ;
				break;
			case 'u':
				fw_op = FW_OP_UPDATE;
				break;
			case 'w':
				flash_op = FLASH_OP_WRITE;
				for (i = 0;i < ERASE_TABLE_MAX;i++)
				{
					if (!strcmp(optarg, EraseSizeTableStr[i]))
					{
						erase_size_index = i;
						break;
					}
				}
				if (i == ERASE_TABLE_MAX)
				{
					printf("Invalid erase size: %s Should be:\n", optarg);
					for (i = 1;i < ERASE_TABLE_MAX;i++)
					{
						printf("%s ", EraseSizeTableStr[i]);
					}
					printf("\n");
					return -1;
				}
				break;
			case 'h':
			case '?':
			default:
				return 0;
		}
	}

	CFile File;
	if (fw_op != FW_OP_NULL)
	{
		if (PMC_FwParserInit())
			goto END;
		if (PMC_FwParserSetFilePath(image_path.GetBuffer()))
			goto END;
		image_path.ReleaseBuffer();
		if (PMC_FwParserFileParse())
			goto END;

		CString strTemp, strInfo;
		DWORD otaAddr, otaSize;
		ImageBinHeader ** pBinHdr;
		int bin_cnt = PMC_FwParserGetBinCnt();
		pBinHdr = PMC_FwParserGetFileInfo();
		if (pBinHdr == NULL)
			goto END;
		otaAddr = PMC_FwParserGetOtaAddr();
		otaSize = PMC_FwParserGetOtaSize();
		strTemp.Format(_T("***********************************************************************************************************\r\n"));
		strInfo += strTemp;
		strTemp.Format(_T("bin version: %d\r\nbin count: %d\r\nOTA address: 0x%08X\r\nOTA size: 0x%08X\r\n"),
			pBinHdr[0]->version, bin_cnt, otaAddr, otaSize);
		strInfo += strTemp;
		strTemp.Format(_T("***********************************************************************************************************\r\n"));
		strInfo += strTemp;
		strTemp.Format(_T("No.\t\t ID\t\t\t Name\t\t sram_offs\t\t data_size\t\t next_section\t attribute\t\t private\r\n"));
		strInfo += strTemp;
		for (i = 0;i < bin_cnt;i++)
		{
			int j;
			CString strID, strName;
			strID = _T("0x");
			for(j = 3;j >= 0;j--)
			{
				CString str;
				str.Format(_T("%02X"), pBinHdr[i]->name[j]);
				strID += str;
			}
			if (pBinHdr[i]->name[0] < sizeof(BinFileName))
				strName.Format(_T("%s"), BinFileName[pBinHdr[i]->name[0]]);
			else
				strName = _T("unknown");
			strTemp.Format(_T(" %-7d 0x%08X\t %-11s 0x%08X\t\t 0x%08X\t\t 0x%08X\t\t 0x%08X\t\t 0x"),
				i + 1,
				strID,
				strName,
				pBinHdr[i]->load_addr, 
				pBinHdr[i]->dsize,
				pBinHdr[i]->next_section_addr,
				pBinHdr[i]->img_attr);
			strInfo += strTemp;
			for(j = 23;j >= 0;j--)
			{
				strTemp.Format(_T("%02X"), pBinHdr[i]->priv[j]);
				strInfo += strTemp;
			}
			strInfo += _T("\r\n");
		}
		printf(strInfo);

		if (fw_op == FW_OP_UPDATE)
		{
			DWORD file_len, cnt_64k, rest_64k, flash_address, length;
			printf("Begin to update firmware:%s\n", image_path);
			if (!File.Open(image_path, CFile::modeRead))
			{
				printf("Open file error:%s\n", image_path);
				goto END;
			}
			file_len = (DWORD)File.GetLength();
			cnt_64k = file_len / FW_UPDATE_SIZE;
			rest_64k = file_len % FW_UPDATE_SIZE;

			pBuf = new BYTE[FW_UPDATE_SIZE];
			if (PMC_Init(com, baud))
			{
				File.Close();
				delete pBuf;
				goto END;
			}
			flash_address = 0;
			length = FW_UPDATE_SIZE;
			for (i = 0;i < cnt_64k;i++)
			{
				printf("Erase block %d, total %d\n", i, cnt_64k);
				if (PMC_EraseFlash(flash_address, length))
				{
					File.Close();
					delete pBuf;
					goto END;
				}
				File.Read(pBuf, length);
				printf("Write block %d, total %d\n", i, cnt_64k);
				if (PMC_WriteFlash(flash_address, pBuf, length))
				{
					File.Close();
					delete pBuf;
					goto END;
				}
				flash_address += FW_UPDATE_SIZE;
			}
			if (rest_64k)
			{
				length = rest_64k;
				printf("Erase rest of 64K:%d\n", length);
				if (PMC_EraseFlash(flash_address, length))
				{
					File.Close();
					delete pBuf;
					goto END;
				}
				File.Read(pBuf, length);
				printf("Write rest of 64K:%d\n", length);
				if (PMC_WriteFlash(flash_address, pBuf, length))
				{
					File.Close();
					delete pBuf;
					goto END;
				}
			}
			File.Close();
			delete pBuf;

			if (otaAddr != 0xFFFFFFFF && otaSize != 0xFFFFFFFF)
			{
				printf("Update OTA data\n");
				int ota_len = 4096;
				BYTE * ota_buf = new BYTE[ota_len];
				if (PMC_GerateOTABuf(ota_buf, ota_len, otaSize))
				{
					delete ota_buf;
					goto END;
				}
				printf("Erase OTA data\n");
				if (PMC_EraseFlashBy4K(otaAddr, ota_len))
				{
					delete ota_buf;
					goto END;
				}
				printf("Write OTA data\n");
				if (PMC_WriteFlash(otaAddr, ota_buf, ota_len))
				{
					delete ota_buf;
					goto END;
				}
				delete ota_buf;
			}
			printf("Update OK!\n\n");
		}
		goto END;
	}

	if (flash_op == FLASH_OP_WRITE)
	{
		//write flash
		DWORD file_len;
		if (!File.Open(file_path, CFile::modeRead))
		{
			printf("Open file error:%s", file_path);
			return -1;
		}

		file_len = (DWORD)File.GetLength();
		if (file_len < length)
		{
			printf("Warning:file size is smaller than %d, write length set to %d!\n",
				length, file_len);
			length = file_len;
		}

		pBuf = new BYTE[length];
		strRes = _T("write flash\n");
		strTemp.Format(_T("com:%d\nbaud:%d\naddress:0x%08X\nlength:%d\n"), com, baud, flash_address, length);
		strRes += strTemp;

		if (PMC_Init(com, baud))
		{
			File.Close();
			delete pBuf;
			goto END;
		}

		if (erase_size_index == 1)//64K
		{
			if (PMC_EraseFlash(flash_address, length))
			{
				goto END;
			}
		}
		else if (erase_size_index == 2)//4K
		{
			if (PMC_EraseFlashBy4K(flash_address, length))
			{
				goto END;
			}
		}
		File.Read(pBuf, length);
		if (PMC_WriteFlash(flash_address, pBuf, length))
		{
			File.Close();
			delete pBuf;
			goto END;
		}
		File.Close();
		delete pBuf;
	}
	else if (flash_op == FLASH_OP_READ)
	{
		//read flash
		if (!File.Open(file_path, CFile::modeCreate | CFile::modeWrite))
		{
			printf("Open file error:%s", file_path);
			return -1;
		}

		pBuf = new BYTE[length];
		strRes = _T("read flash\n");
		strTemp.Format(_T("com:%d\nbaud:%d\naddress:0x%08X\nlength:%d\n"), com, baud, flash_address, length);
		strRes += strTemp;

		if (PMC_Init(com, baud))
		{
			File.Close();
			delete pBuf;
			goto END;
		}
		if (PMC_ReadFlash(flash_address, pBuf, length))
		{
			File.Close();
			delete pBuf;
			goto END;
		}
		File.Write(pBuf, length);
		File.Close();
		delete pBuf;
	}
	else if (flash_op == FLASH_OP_ERASE)
	{
		//erase flash
		strRes = _T("erase flash\n");
		strTemp.Format(_T("com:%d\nbaud:%d\naddress:0x%08X\nerase size:%s\nlength:%d\n"),
			com, baud, flash_address, EraseSizeTableStr[erase_size_index], length);
		strRes += strTemp;

		if (PMC_Init(com, baud))
		{
			goto END;
		}

		if (erase_size_index == 1)//64K
		{
				if (PMC_EraseFlash(flash_address, length))
				{
					goto END;
				}
		}
		else if (erase_size_index == 2)//4K
		{
			if (PMC_EraseFlashBy4K(flash_address, length))
			{
				goto END;
			}
		}
		//don't process in other case
	}
END:
	strTemp.Format(_T("%s\n"), PMC_GetMsg());
	strRes += strTemp;
	printf(strRes);
	PMC_Deinit();
	PMC_FwParserDeinit();

	return 0;
}

